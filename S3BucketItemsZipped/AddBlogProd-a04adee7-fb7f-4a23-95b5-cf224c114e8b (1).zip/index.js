const AWS = require('aws-sdk')
AWS.config.update({region: 'us-east-1'})

var documentClient = new AWS.DynamoDB.DocumentClient();
var dynamoDBTable = 'Blogs'
var sqs = new AWS.SQS({ apiVersion: '2012-11-05' });
var sqsQueueName = 'BlogItQueueProd';

exports.handler = async (event) => {
      const requestBody = JSON.parse(event.body);

  const {
    email,
    blog_id,
    content
  } = requestBody
  
  try {
    const params = {
      TableName: dynamoDBTable,
      Item: {
        email: email,
        blog_id: blog_id,
        content: content
      },
    };
    console.log(params)
    await documentClient.put(params).promise();
    
    // Send blog information to SQS queue
    const sqsParams = {
      QueueName: sqsQueueName,
    };
    
    const sqsQueueData = await sqs.getQueueUrl(sqsParams).promise();
    const sqsQueueUrl = sqsQueueData.QueueUrl;
    
    // Send blog information to the retrieved SQS queue URL
    const sendMessageParams = {
      MessageBody: JSON.stringify({ email, blog_id, content }),
      QueueUrl: sqsQueueUrl,
    };
    
    await sqs.sendMessage(sendMessageParams).promise();
    
    const response = {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
        "Access-Control-Allow-Credentials" : true // Required for cookies, authorization headers with HTTPS
      },
      body: JSON.stringify({message: 'User blog stored and sent to sqs'}),
    };
    return response;
  } catch (e) {
    return {
      statusCode: 500,
      body: JSON.stringify({e: 'failed to store'})
    }
  }
};
